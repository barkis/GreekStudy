#ifndef GREEKEDIT
#define GREEKEDIT
#include "stdafx.h"
#include "GreekVocabDoc.h"
#include "GreekVocabView.h"
#include "MainFrm.h"
#include "ScrollEdit.h"
#include <map>

class CGreekEdit: public CEdit	{
public:
	CGreekEdit();
	static void SetFrame(CMainFrame *pFrame);
protected:	
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	static CMainFrame *m_pTheFrame;
	BOOL OnKillFocus();
	void Sigmify();

private:
	static const short CKEY = 0x43;
	static const short VKEY = 0x56;

	const Shifts GetShift();
	bool m_bIsMultiline;
public:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSetFocus();
	virtual void PreSubclassWindow();
};
#endif
