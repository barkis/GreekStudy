//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GreekVocab.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_GreekVocabTYPE              130
#define IDD_ENTER                       310
#define IDD_TEST1                       311
#define IDD_ENTRYTEST                   311
#define IDD_DIALOGHOVERTEST             313
#define IDD_DIALOGFILENAMES             314
#define IDR_ACCELERATOR1                315
#define IDD_DIALOGNOUN                  316
#define IDD_DIALOGDECLENSIONNAMES       317
#define IDD_DIALOGNOUNNAMES             317
#define IDD_DIAOGADJECTIVE              318
#define IDD_DIALOGADJECTIVE             318
#define IDD_DIALOGVERB                  319
#define IDD_DIALOGVERBSHEET             320
#define IDSAVE                          1000
#define IDC_EDITEN                      1001
#define IDBUTTONSAVEANDCONTINUE         1001
#define IDC_EDITGK                      1002
#define IDBUTTONCLEAR                   1002
#define IDBUTTONEDIT                    1003
#define IDC_EDITDECLENSION              1005
#define IDC_TRY                         1006
#define IDC_EDITDICTIONARYFORM          1006
#define IDC_LISTGK                      1007
#define IDC_EDITNOMS                    1007
#define IDC_COMBOFILES                  1008
#define IDC_EDITACCS                    1008
#define IDC_LISTEN                      1009
#define IDC_EDITGENS                    1009
#define IDC_BUTTONSHOW                  1010
#define IDC_EDITNOMP                    1010
#define IDC_LISTHOVER                   1011
#define IDC_EDITACCP                    1011
#define IDC_COMBOHOVER                  1012
#define IDC_EDITGENP                    1012
#define IDC_BUTTONEDIT                  1013
#define IDC_EDITVOC                     1013
#define IDC_LISTEDITFILES               1014
#define IDC_LISTFILENAMES               1014
#define IDC_EDITDATP                    1014
#define IDC_EDITDATS                    1015
#define IDC_LISTNOUNNAMES               1017
#define IDC_COMBODECLENSIONNAMES        1019
#define IDC_STATICDECLENSION            1019
#define IDC_EDITNOMPF                   1021
#define IDC_EDITACCPF                   1022
#define IDC_EDITGENPF                   1023
#define IDC_EDITDATPF                   1024
#define IDC_EDITNOMSN                   1026
#define IDC_EDITACCSN                   1027
#define IDC_EDITGENSN                   1028
#define IDC_EDITDATSN                   1029
#define IDC_EDITNOMPN                   1030
#define IDC_EDITACCPN                   1031
#define IDC_EDITGENPN                   1032
#define IDC_EDITDATPN                   1033
#define IDC_EDITNOMSM                   1035
#define IDC_EDITACCSM                   1036
#define IDC_EDITGENSM                   1037
#define IDC_EDITDATSM                   1038
#define IDC_EDITNOMPM                   1039
#define IDC_EDITACCPM                   1040
#define IDC_EDITGENPM                   1041
#define IDC_EDITDATPM                   1042
#define IDC_EDITNOMSF                   1043
#define IDC_EDITACCSF                   1044
#define IDC_EDITGENSF                   1045
#define IDC_EDITDATSF                   1046
#define IDBUTTONSAVE                    1047
#define IDC_COMBOARTICLE                1049
#define IDC_EDITVOCM                    1050
#define IDC_TABVERB                     1051
#define IDC_EDIT1                       1052
#define IDC_EDIT2                       1053
#define IDC_EDIT3                       1054
#define IDC_EDIT4                       1055
#define IDC_EDIT5                       1056
#define IDC_EDIT6                       1057
#define IDC_EDIT7                       1058
#define IDC_EDIT8                       1059
#define IDC_EDIT9                       1060
#define IDC_BUTTON1                     1061
#define ID_VOCABULARY_ENTRY             32776
#define ID_VOCABULARY_ENTRYTEST         32777
#define ID_VOCABULARY_HOVERTEST         32778
#define ID_GRAMMAR_NOUNS                32783
#define ID_NOUNS_ENTRYTEST              32788
#define ID_ADJECTIVES_ENTER             32791
#define ID_HELP_HELPTOPICS              32794
#define ID_VERBS_ENTER                  32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        321
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1062
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
