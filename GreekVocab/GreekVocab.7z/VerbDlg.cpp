// VerbDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GreekVocab.h"
#include "VerbDlg.h"
#include "afxdialogex.h"
#include "VerbSheetDlg.h"

// CVerbDlg dialog

IMPLEMENT_DYNAMIC(CVerbDlg, CDialogEx)

	CVerbDlg::CVerbDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CVerbDlg::IDD, pParent)
{

}

CVerbDlg::~CVerbDlg()
{
}

void CVerbDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TABVERB, m_TabSheet);
}


BEGIN_MESSAGE_MAP(CVerbDlg, CDialogEx)
END_MESSAGE_MAP()


// CVerbDlg message handlers


BOOL CVerbDlg::OnInitDialog()
{
	TRACE0("In CVerbDlg::OnInitDialog\n");
	CDialogEx::OnInitDialog();
	m_TabSheet.InsertItem(0,_T("Active Present"));
	m_TabSheet.InsertItem(1,_T("Middle Present"));
	//m_pVerbSheet = new CVerbSheetDlg;
	//m_pVerbSheet->Create(IDD_DIALOGVERBSHEET,this);
	//PositionDialog(*m_pVerbSheet);
	//Invalidate();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CVerbDlg::PositionDialog(CDialog &dlg)	{

	/*CRect rectClient,rectDlg;
	CRect rectWnd,rectParent,rectTab;
	m_TabSheet.GetItemRect(0,&rectTab);
	m_TabSheet.GetClientRect(&rectClient);
	m_TabSheet.ClientToScreen(&rectClient);*/
}
