// VerbSheetDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GreekVocab.h"
#include "VerbSheetDlg.h"
#include "afxdialogex.h"


// CVerbSheetDlg dialog

IMPLEMENT_DYNAMIC(CVerbSheetDlg, CDialogEx)

CVerbSheetDlg::CVerbSheetDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CVerbSheetDlg::IDD, pParent)
{

}

CVerbSheetDlg::~CVerbSheetDlg()
{
}

void CVerbSheetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CVerbSheetDlg, CDialogEx)
END_MESSAGE_MAP()


// CVerbSheetDlg message handlers
