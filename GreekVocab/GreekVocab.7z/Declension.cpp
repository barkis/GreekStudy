#include "stdafx.h"
#include "Declension.h"
#include "util.h"
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <string>
#include <set>
#include <exception>
#include <iostream>

 

CDeclension::~CDeclension(void)
{
}

std::ostream& operator<<(std::ostream &os,CDeclension &declension)	{
	//os << "<declension>" << '\n';
	//os << util::TagifyContents(_T("dictionary form"),_T("dictionaryform")) /*<<_T('\n')*/;
	os << declension.m_strNominativeS<<'\n';
	return os;
}

std::istream& operator>>(std ::istream &is,CDeclension &declension)	{
	return is;
}

const void CGrammarExample::WriteHead(CStdioFile &FileOut)	{
	FileOut.WriteString(m_strPartOfSpeech + _T("\n"));
	FileOut.WriteString(m_strDescription + _T("\n"));
	FileOut.WriteString(m_strDictionaryForm + _T("\n"));
}

const void CGrammarExample::WriteTail(CStdioFile &pFileOut)	{
	pFileOut.WriteString(_T("/") + m_strPartOfSpeech + _T("\n"));
}

bool CDeclension::Read(CStdioFile &fileIn)	{
	CString strDummy;
	bool bFound = fileIn.ReadString(m_strDescription);
	if(bFound)	{
		bFound = fileIn.ReadString(m_strDictionaryForm);
	}	
	if(bFound)	{
		bFound = fileIn.ReadString(strDummy);
	}
	if(bFound)	{
		bFound = fileIn.ReadString(m_strNominativeS);
	}
	if(bFound)	{
		bFound = fileIn.ReadString(m_strAccusativeS);
	}
	if(bFound)	{
		bFound = fileIn.ReadString(m_strGenitiveS);
	}
	if(bFound)	{
		bFound = fileIn.ReadString(m_strDativeS);
	}
	if(bFound)	{
		bFound = fileIn.ReadString(m_strNominativeP);
	}
	if(bFound)	{
		bFound = fileIn.ReadString(m_strAccusativeP);
	}
	if(bFound)	{
		bFound = fileIn.ReadString(m_strGenitiveP);
	}
	if(bFound)	{
		bFound = fileIn.ReadString(m_strDativeP);
	}
	if(bFound)	{
		CString strNextString;
		bFound = fileIn.ReadString(strNextString);
		if(bFound && strNextString.Left(1) != _T("/"))	{
			m_strVocative = strNextString;
		}
	}
	return bFound;
}
//
const void CDeclension::Write(CStdioFile &FileOut)	{
	FileOut.WriteString(m_strNominativeS + _T("\n"));
	FileOut.WriteString(m_strAccusativeS + _T("\n"));
	FileOut.WriteString(m_strGenitiveS + _T("\n"));
	FileOut.WriteString(m_strDativeS + _T("\n"));
	FileOut.WriteString(m_strNominativeP + _T("\n"));
	FileOut.WriteString(m_strAccusativeP + _T("\n"));
	FileOut.WriteString(m_strGenitiveP + _T("\n"));
	FileOut.WriteString(m_strDativeP + _T("\n"));
	FileOut.WriteString(m_strVocative + _T("\n"));
}
const void CNoun::Write(CStdioFile &FileOut)	{
	WriteHead(FileOut);
	FileOut.WriteString(m_strArticle + _T("\n"));
	CDeclension::Write(FileOut);
	WriteTail(FileOut);
}

bool CAdjective::Read(CStdioFile &filein)	{
	bool bFound;
	bFound = m_MascDecl.Read(filein);

	if(bFound)	{
		bFound = m_FemDecl.Read(filein);
	}

	if(bFound)	{
		bFound = m_NeutDecl.Read(filein);
	}

	return bFound;
}

const void CAdjective::Write(CStdioFile &fileOut)	{
	WriteHead(fileOut);
	m_MascDecl.Write(fileOut);
	m_FemDecl.Write(fileOut);
	m_NeutDecl.Write(fileOut);
	WriteTail(fileOut);
}