
// GreekVocabView.h : interface of the CGreekVocabView class
//

#pragma once
#include <map>
#include <vector>

class CGreekVocabView : public CScrollView
{
protected: // create from serialization only
	CGreekVocabView();
	DECLARE_DYNCREATE(CGreekVocabView);

// Attributes
public:
	CGreekVocabDoc* GetDocument() const;
// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CGreekVocabView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CRichEditCtrl m_rich;
private:
	static const int COLWIDTH = 200;
	static const int YSTART = 3;
	std::vector<std::basic_string<TCHAR>> m_vEntries;
	std::vector<int> m_vLinesToDraw;
	int m_xPos,m_yPos;

	void ReadFiles();
	void ReadLines(CStdioFile &file);
	void SetScroll(int MaxSize);
protected:
	CDialogEx *m_pDlg;
// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:

	afx_msg void OnVocabularyEntry();
	virtual void OnInitialUpdate();
	afx_msg void OnVocabularyTest();
	afx_msg void OnVocabularyHovertest();
	afx_msg void OnGrammarNouns();
	afx_msg void OnNounsEntrytest();
	afx_msg void OnAdjectivesEnter();
	afx_msg void OnHelpHelptopics();
	afx_msg void OnVerbsEnter();
};

#ifndef _DEBUG  // debug version in GreekVocabView.cpp
inline CGreekVocabDoc* CGreekVocabView::GetDocument() const
   { return reinterpret_cast<CGreekVocabDoc*>(m_pDocument); }
#endif

