#pragma once
#include "afxcmn.h"


// CVerbDlg dialog
class CVerbSheetDlg;

class CVerbDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CVerbDlg)

public:
	CVerbDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CVerbDlg();

// Dialog Data
	enum { IDD = IDD_DIALOGVERB };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
private:
	CTabCtrl m_TabSheet;
	CVerbSheetDlg *m_pVerbSheet;
	void PositionDialog(CDialog &dlg);
public:
	virtual BOOL OnInitDialog();
};
